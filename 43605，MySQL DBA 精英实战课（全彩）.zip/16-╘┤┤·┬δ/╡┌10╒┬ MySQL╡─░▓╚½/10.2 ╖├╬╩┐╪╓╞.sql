-- 查看 MySQL 用户信息
select user,host,authentication_string,account_locked frommysql.user;