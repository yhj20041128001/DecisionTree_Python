-- 创建角色
create role 'DBA';

-- 授权
grant all on *.* to 'DBA';

-- 角色使用
create user dba_zhangsan@'%' identified by 'dba1pass';
grant DBA to dba_zhangsan@'%';

-- 查看当前用户的哪些角色被激活了：
select CURRENT_ROLE();

-- 激活角色
set default role all to dba_zhangsan@'%';

-- 角色回收
revoke role from user;

-- 回收角色权限
revoke all on *.* from 'DBA';

-- 角色删除
drop role 'DBA';