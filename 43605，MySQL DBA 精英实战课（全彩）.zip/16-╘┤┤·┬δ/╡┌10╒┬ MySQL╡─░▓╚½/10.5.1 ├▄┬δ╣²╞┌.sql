-- 先创建测试用户
create user 'test_user'@'localhost' identified by 'abcABC123';
grant select on test.* to 'test_user'@'localhost';


-- 查看用户'test_user'@'localhost'在mysql.user 表中的密码过期情况
select user,host,password_expired from mysql.user where user='test_user' and host='localhost';

-- 可以使用下面的语句使账号过期
alter user test_user@'localhost' password expire;

-- 再次查看用户'test_user'@'localhost'在mysql.user 表中的密码过期情况
select user,host,password_expired from mysql.user where user='test_user' and host='localhost';


-- 数设置数据库的全局密码过期策略
set persist default_password_lifetime = 180;

-- 为用户单独设置过期策略
alter user 'test_user'@'localhost' password expire interval 90 DAY;

-- 禁用密码过期
alter user 'test_user'@'localhost' password expire never;

-- 遵循全局策略
alter user 'test_user'@'localhost' password expire default;