-- 动态配全局密码策略
set persist password_history = 5;
set persist password_reuse_interval = 365;

-- 禁止用户'test_user'@'localhost'重复使用最近的5 个密码
alter user 'test_user'@'localhost' password history 5;

-- 禁止用户'test_user'@'localhost'重复使用历史密码中不超过365 天的密码
alter user 'test_user'@'localhost' password reuse interval 365 day;

-- 禁止用户'test_user'@'localhost'重复使用最近的5 个密码和历史密码中不超过365 天的密码
alter user 'test_user'@'localhost' password history 5 password reuse interval 365 day;

