-- 设置用户修改密码是否需要验证原密码
set persist password_require_current = ON;
set persist password_require_current = OFF;


-- 为用户单独创建密码验证
alter user 'test_user'@'localhost' password require current;

-- 删除策略
alter user 'test_user'@'localhost' password require current optional;

-- 遵循全局策略
alter user 'test_user'@'localhost' password require current default;

