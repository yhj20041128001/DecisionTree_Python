-- 创建主密码，将当前密码设置为辅助密码
alter user 'test_user'@'localhost' identified by 'password_b' retain current password;

-- 删除辅助密码
alter user 'test_user'@'localhost' discard old password;