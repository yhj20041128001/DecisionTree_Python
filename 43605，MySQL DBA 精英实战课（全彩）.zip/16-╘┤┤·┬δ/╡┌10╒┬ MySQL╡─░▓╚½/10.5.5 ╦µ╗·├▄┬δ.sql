-- 使用随机密码
create user 'user1'@'%' identified by random password;