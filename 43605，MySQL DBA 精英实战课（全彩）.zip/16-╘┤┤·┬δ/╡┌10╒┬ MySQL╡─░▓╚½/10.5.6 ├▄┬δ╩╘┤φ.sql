-- 配置用户登录的最大失败次数和超过后账户的锁定时间

create user 'tom_dba'@'localhost' identified by 'password' FAILED_LOGIN_ATTEMPTS 4 PASSWORD_LOCK_TIME 3;

alter user 'tom_dba'@'localhost' FAILED_LOGIN_ATTEMPTS 7 PASSWORD_LOCK_TIME UNBOUNDED;