-- 限制账户资源
create user 'lihao'@'localhost' identified by 'frank' with MAX_QUERIES_PER_HOUR 20 MAX_UPDATES_PER_HOUR 10 MAX_CONNECTIONS_PER_HOUR 5 MAX_USER_CONNECTIONS 2;

alter user 'lihao'@'localhost' with MAX_QUERIES_PER_HOUR 100;