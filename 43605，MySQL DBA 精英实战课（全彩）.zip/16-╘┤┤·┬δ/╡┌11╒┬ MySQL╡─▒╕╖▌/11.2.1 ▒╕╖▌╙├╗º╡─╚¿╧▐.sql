-- MySQL 中创建好用于备份的用户
create user `u_bak`@`%` identified with mysql_native_password by 'NJidagp781@';
-- 配置合适的权限
grant select, reload, process, lock tables, replication client,replication_slave_admin,show view, trigger on *.* to `u_bak`@`%`;