-- 在运行MySQL 时加载Clone Plugin
install plugin clone SONAME 'mysql_clone.so';

-- 确定插件是否安装成功
select plugin_name, plugin_status from information_schema.plugins where plugin_name = 'clone';

