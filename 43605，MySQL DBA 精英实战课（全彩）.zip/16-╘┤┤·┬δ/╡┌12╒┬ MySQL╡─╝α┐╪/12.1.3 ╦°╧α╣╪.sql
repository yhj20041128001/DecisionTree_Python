-- 表锁情况
show global status like "table_locks_waited";

-- InnoDB 正在等待行锁的数量
show global status like "innodb_row_lock_current_waits";

-- 行锁总耗时
show global status like "innodb_row_lock_time";

-- 行锁平均耗时
show global status like "innodb_row_lock_time_avg";

-- 行锁最久耗时
show global status like "innodb_row_lock_time_max";

-- 行锁发生次数
show global status like "innodb_row_lock_waits";