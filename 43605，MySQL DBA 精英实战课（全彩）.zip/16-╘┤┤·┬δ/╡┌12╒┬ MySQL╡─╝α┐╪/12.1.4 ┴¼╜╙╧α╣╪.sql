-- 查看当前连接数
show global status like "threads_connected";

-- 查看最大连接数
show global variables like "max_connections";


-- 获取活跃连接数
show global status like "Threads_running";

-- 客户端异常中断数
show global status like "Aborted_clients";