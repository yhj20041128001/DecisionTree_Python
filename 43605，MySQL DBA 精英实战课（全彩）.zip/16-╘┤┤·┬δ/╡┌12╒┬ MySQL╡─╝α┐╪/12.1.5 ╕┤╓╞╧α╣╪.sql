-- 查看是否为 read only
show global variables like "read_only";