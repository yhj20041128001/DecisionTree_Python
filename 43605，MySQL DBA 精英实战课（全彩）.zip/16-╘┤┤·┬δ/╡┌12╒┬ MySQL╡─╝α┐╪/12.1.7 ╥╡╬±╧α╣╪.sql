-- 自增值auto_increment 的获取方式如下
select auto_increment from tables where table_schema='xxx' and table_name='xxx';

-- 获取表数据量的SQL 语句如下
select table_rows from information schema.tables where table_schema='xxx' and table_name='sys_menu_0';