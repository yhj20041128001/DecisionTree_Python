-- 在 MySQL 上创建监控用户
create user 'exporter'@'127.0.0.1' identified by 'eXpHdB666QWE!';
grant select, process, super, replication client, reload on *.* to 'exporter'@'127.0.0.1';