package main
import (
"fmt"
"github.com/xxx/rds"
)
func main() {
client, err := rds.NewClientWithAccessKey("cn-shanghai",
"<accessKeyId>", "<accessSecret>")
request := rds.CreateDescribeDBInstanceAttributeRequest()
request.Scheme = "https"
request.DBInstanceId = "xxx"
response, err := client.DescribeDBInstanceAttribute(request)
if err != nil {
fmt.Print(err.Error())
}
fmt.Printf("response is %#v\n", response)
}