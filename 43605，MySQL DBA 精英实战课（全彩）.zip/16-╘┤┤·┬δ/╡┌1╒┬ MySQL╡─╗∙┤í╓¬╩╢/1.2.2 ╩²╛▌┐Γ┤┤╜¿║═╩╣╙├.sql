-- 创建test 数据库
create database test;

-- 使用test 数据库
use test