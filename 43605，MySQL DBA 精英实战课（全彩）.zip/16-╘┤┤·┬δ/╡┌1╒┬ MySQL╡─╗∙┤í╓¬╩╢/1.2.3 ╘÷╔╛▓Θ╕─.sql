-- 建表
create table t ( id int primary key auto_increment ,name varchar(10));

-- 插入
insert into t values(1,'张三');

-- 查询
select * from t;

-- 更新
update t set name='李四' where id = 1;

-- 删除
delete from t where id = 1;

--删除后查询
select * from t;