-- 使用 test 库
use test;

-- 创建一张测试表并写入数据
create table `t1` (
`id` int not null auto_increment,
`a` int not null,
`b` char(2) not null,
primary key (`id`),
key `idx_a` (`a`)
) engine=innodb default charset=utf8mb4;

insert into t1(a,b) values (1,'a'),(2,'b'),(3,'c'),(5,'e'),(6,'f'),(7,'g'),(9,'i');

-- 查看表t1 中的所有数据
select * from t1;

