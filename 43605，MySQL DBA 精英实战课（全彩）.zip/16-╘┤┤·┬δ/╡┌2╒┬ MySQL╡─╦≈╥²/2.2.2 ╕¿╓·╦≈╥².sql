-- 在建表的时候创建索引
create table `t1` (
`id` int not null auto_increment,
`a` int not null,
`b` char(2) not null,
primary key (`id`),
key `idx_a` (`a`)
) engine=innodb default charset=utf8mb4;

-- 使用create index语句创建索引
create index idx_b on t1(b);

-- 查看表t1 上的索引
show index from t1\G

-- 删除索引
drop index idx_b on t1;


-- 使用alter table 语句创建索引
alter table t1 add index idx_b(b);

-- 删除索引
alter table t1 drop index idx_b;