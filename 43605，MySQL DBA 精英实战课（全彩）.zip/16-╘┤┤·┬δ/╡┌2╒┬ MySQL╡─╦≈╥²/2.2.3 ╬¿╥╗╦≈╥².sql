-- 为b字段第一个字符添加唯一索引
alter table t1 add unique uniq_b(b(1));

-- 写入数据
insert into t1(a,b) select 1,'nn';