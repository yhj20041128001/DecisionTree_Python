-- 创建测试表t2
create table `t2` (
`id` int not null auto_increment,
`a` int not null,
`b` char(2) not null,
`c` datetime not null default current_timestamp,
primary key (`id`),
key `idx_a_b` (`a`,`b`)
) engine=innodb default charset=utf8mb4;

-- 并写入测试数据
insert into t2(a,b) values (1,'c'),(2,'b'),(3,'a'),(5,'e'),(6,'i'),(7,'g'),(9,'f');

-- a 字段和b 字段都作为条件时的执行计划
explain select c from t2 where a=1 and b='c'\G

-- 只有a 字段作为条件时的执行计划
explain select c from t2 where a=1\G

-- 只有b 字段作为条件时的执行计划
explain select c from t2 where b='c'\G

-- 覆盖索引例子
explain select b from t2 where a=1\G