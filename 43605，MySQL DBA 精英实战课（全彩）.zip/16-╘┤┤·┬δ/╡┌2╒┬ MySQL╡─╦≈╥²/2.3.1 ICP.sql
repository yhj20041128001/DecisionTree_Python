-- 使用 test 库
use test;

-- 创建测试表t3
create table `t3` (
`id` int not null auto_increment,
`a` int not null,
`b` char(2) not null,
`c` datetime not null default current_timestamp,
primary key (`id`),
key `idx_a_b` (`a`,`b`)
) engine=innodb default charset=utf8mb4;

-- 写入测试数据
insert into t3(a,b) values (1,'cj'),(2,'bk'),(3,'al'),(5,'em'),(6,'in'),(7,'go'),(9,'fp');


-- 如果要通过字段a 和字段b 查询字段c 的值，但是字段b 的值只知道最后一个字母
select c from t3 where a=1 and b like '%j';

-- 关闭 ICP
set optimizer_switch = 'index_condition_pushdown=off';

-- 查看执行计划
explain select c from t3 where a=1 and b like '%j'\G

-- 打开 ICP
set optimizer_switch = 'index_condition_pushdown=on';

-- 再次查看执行计划
explain select c from t3 where a=1 and b like '%j'\G