-- 环境准备
create table t(id int not null Auto increment, b int, primary
key(`id`));
insert into t select 1,1;
insert into t select 2,1;
insert into t select 7,1;
insert into t select 9,1;
insert into t select 10,1;
insert into t select 11,1;
insert into t select 12,1;
insert into t select 13,1;

-- 事务A 执行如下语句
begin;
select * from t where id = 10 for update;

-- 事务B 执行如下语句
lock tables t read;


事务A 执行如下语句
begin;
select * from t where id = 11 for update;

事务B 执行如下语句
begin;
select * from t where id = 12 for update;