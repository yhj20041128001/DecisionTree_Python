-- 环境准备语句
create table yue (
a int default null,
b int default null,
c int default null,kl
unique key idx_a (a),
key idx_b (b)
) engine=innodb default charset=utf8mb4;
insert into yue select 1,2,3;
insert into yue select 2,3,4;
insert into yue select 3,4,5;
insert into yue select 4,5,6;
insert into yue select 5,6,7;
insert into yue select 6,7,8;
insert into yue select 7,8,8;
insert into yue select 8,9,10;
insert into yue select 9,10,10;

-- 1.记录锁的演示
-- 线程A 如下：
begin;
select * from yue where a = 3 for update;
-- 线程B 如下：
begin;
update yue set c=7 where a=3;

-- 2.间隙锁的演示
-- 线程A 如下
begin;
select * from yue where b between 2 and 6 for update;

-- 线程B 如下
begin;
insert into yue select 10,2,2;
insert into yue select 10,6,2;
insert into yue select 10,7,2;