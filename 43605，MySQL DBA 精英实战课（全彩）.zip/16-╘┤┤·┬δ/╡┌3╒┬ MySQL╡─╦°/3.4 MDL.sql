-- 创建3个具有相同结构的表
create table t (id int);
create table t_new like t;
create table new_t like t;

-- 场景一
-- 线程1 如下:
lock table t write, t_new write;
-- 线程2 如下:
insert into t values(1);
-- 线程3 如下：
rename table t to t_old, t_new to t;
-- 线程1 如下：
unlock tables;

-- 场景二
-- 线程1 如下：
lock table t write, new_t write;
-- 线程2 如下：
insert into t values(1);
-- 线程3 如下：
rename table t to old_t, new_t to t;
-- 线程1 如下：
unlock tables;

-- 在线开启metadata_locks
update performance_schema.setup_instruments set enabled = 'yes' where name ='wait/lock/metadata/sql/mdl';