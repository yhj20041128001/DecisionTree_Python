-- 创建测试表并写入数据
use martin;
drop table if exists dl;
create table `dl` (
`id` int not null auto_increment,
`a` int not null,
`b` int not null,
`c` int not null,
primary key (`id`),
key `idx_c` (`a`)
) engine=innodb default charset=utf8mb4;
drop table if exists dl_insert
create table `dl_insert` (
`id` int not null auto_increment,
`a` int not null,
`b` int not null,
`c` int not null,
primary key (`id`),
unique key `uniq_a` (`a`)
) engine=innodb default charset=utf8mb4;
insert into dl(a,b,c) values (1,1,1),(2,2,2);
drop table if exists dl_1;
create table dl_1 like dl;
insert into dl_1 select * from dl;

-- 场景1：同一张表的死锁实验
-- session1
begin;
select * from dl where a=1 for update;
select * from dl where a=2 for update;
commit;

-- session2
begin;
select * from dl where a=2 for update;
select * from dl where a=1 for update;
commit;

-- 场景2：不同表的死锁实验
-- session1
begin;
select * from dl where a=1 for update;
select * from dl_1 where a=1 for update;
commit;

-- session2
begin;
select * from dl_1 where a=1 for update;
select * from dl where a=1 for update;
commit;

-- 场景3：间隙锁导致的死锁实验
-- session1
set session transaction_isolation='REPEATABLEREAD';
begin;
select * from dl where a=1 for update;
insert into dl(a,b,c) values (2,3,3);
commit;

-- session2
set session transaction_isolation='REPEATABLEREAD';
begin;
select * from dl where a=2 for update;
insert into dl(a,b,c) values (1,4,4);
commit;

-- 场景4：insert 语句的死锁实验
-- session1
begin;
insert into dl_insert(a,b,c) value (3,3,3);
rollback;

-- session2
insert into dl_insert(a,b,c) value (3,3,3);

-- session3
insert into dl_insert(a,b,c) value(3,3,3);

清空表dl_insert：
truncate table dl_insert;