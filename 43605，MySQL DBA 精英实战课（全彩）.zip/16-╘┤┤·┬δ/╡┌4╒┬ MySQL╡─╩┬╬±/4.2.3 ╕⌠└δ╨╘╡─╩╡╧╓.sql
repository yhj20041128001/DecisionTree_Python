-- 查看当前会话的隔离级别
select @@transaction_isolation;

-- 查看全局的隔离级别
select @@global.transaction_isolation;

-- 设置当前会话的隔离级别，可选择READ UNCOMMITTED、READ COMMITTED、
REPEATABLE READ、SERIALIZABLE
set session transaction isolation level REPEATABLE READ;

-- 设置全局的隔离级别
set global transaction isolation level REPEATABLE READ;

-- 查看当前某个会话事务的隔离级别
select variable_name,variable_value from performance_schema.variables_by_thread where thread_id IN (SELECT thread_id from performance_schema.threads where processlist_id =4686370)and variable_name = 'transaction_isolation';