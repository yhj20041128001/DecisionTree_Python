-- 环境准备
create table `t1` (
`id` int not null auto_increment,
`a` int not null,
`b` int not null,
primary key (`id`)
) engine=innodb charset=utf8mb4;
insert into t1(a,b) values (1,1);

-- 更新表t1 中的数据
update t1 set a=3 where a=1;

-- 再次更新表t1 中的数据：
update t1 set a=4 where a=3;