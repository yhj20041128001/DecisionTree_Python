-- 创建测试表并写入数据：
create table t(
id int primary key,
age int,
key idx_age(age)
);
insert into t values (1,1),(2,3),(3,4),(4,4),(5,7),(6,7),(7,10),(8,11);

-- 临键锁的例子
-- 线程A
begin;
delete from t where age = 7;

-- 线程B
begin;
insert into t select 9,3;
insert into t select 10,4;
insert into t select 10,7;
insert into t select 10,9;
insert into t select 10,10;

