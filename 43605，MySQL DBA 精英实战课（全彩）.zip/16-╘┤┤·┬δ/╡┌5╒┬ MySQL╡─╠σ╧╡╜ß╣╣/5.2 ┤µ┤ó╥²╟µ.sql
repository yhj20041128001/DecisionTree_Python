-- 查询MySQL 数据库支持哪些存储引擎
show engines\G