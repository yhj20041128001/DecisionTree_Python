-- 查看自适应哈希索引的使用情况
show engine innodb status

