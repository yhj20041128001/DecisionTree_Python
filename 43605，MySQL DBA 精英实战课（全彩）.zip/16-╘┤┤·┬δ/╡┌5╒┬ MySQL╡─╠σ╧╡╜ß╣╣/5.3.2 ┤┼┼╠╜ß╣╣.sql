-- 创建一张InnoDB 表
use test;
create table yzl(
a int not null auto_increment primary key,
name varchar(20)
) engine=innodb;

-- 查看表属性
show table status from test like 'yzl' \G

-- 通过information_schema.innodb_tables 表查看表属性
select * from information_schema.innodb_tables where name='test/yzl'\G

