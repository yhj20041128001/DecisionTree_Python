-- 查看当前Binlog 的位点
show master status\G

-- 创建一张表
create table a(id int);

-- 查看Binlog 信息
show binlog events in 'mysql-bin.000014' from 50089725 limit 5\G


