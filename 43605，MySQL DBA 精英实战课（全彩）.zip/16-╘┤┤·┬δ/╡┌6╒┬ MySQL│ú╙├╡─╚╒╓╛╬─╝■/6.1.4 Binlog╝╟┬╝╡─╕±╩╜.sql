-- 修改参数binlog_format 的全局值的方法如下
set global binlog_format = 'row';

-- 修改参数binlog_format 的会话级别的方法如下
set session binlog_format = 'row';