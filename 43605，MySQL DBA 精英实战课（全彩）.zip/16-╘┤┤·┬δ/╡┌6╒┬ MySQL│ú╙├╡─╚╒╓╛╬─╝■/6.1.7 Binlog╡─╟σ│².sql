-- 显示Binlog文件
show binary logs;

-- 删除指定Binlog 之前的文件
purge binary logs to 'mysql-bin.000002';

-- 删除指定时间之前的Binlog 文件
purge binary logs before '2020-12-20 00:06:00';

-- 查看binlog_expire_logs_seconds的值
show global variables like 'binlog_expire_logs_seconds' ;

-- 设置查看binlog_expire_logs_seconds的值
set global binlog_expire_logs_seconds = 1296000;

-- 日志刷新
flush logs;