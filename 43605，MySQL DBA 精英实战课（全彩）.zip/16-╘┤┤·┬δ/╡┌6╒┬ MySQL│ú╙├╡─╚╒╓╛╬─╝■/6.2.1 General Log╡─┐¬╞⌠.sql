-- 开启 General Log
set global general_log = on;
set global general_log_file = "/data/mysql/log/mysql-general.
log";


