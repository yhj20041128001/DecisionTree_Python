-- 确定General Log 是否开启
show global variables like "general%";

-- 确定General Log的输出方式
show global variables like "log_output";

-- 进入MySQL 执行一条查询语句
select * from test.a;