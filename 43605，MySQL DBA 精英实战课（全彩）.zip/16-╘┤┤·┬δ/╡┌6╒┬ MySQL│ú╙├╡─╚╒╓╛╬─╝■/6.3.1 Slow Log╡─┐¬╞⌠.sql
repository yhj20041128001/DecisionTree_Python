-- 开启Slow Log
set global slow_query_log = 1;

-- 设置 slow log 日志
set global slow_query_log_file = "/data/mysql/log/mysql-slow.log";

-- 设置慢查询阈值
set global long_query_time=1;