-- 确定是否开启慢查询
show global variables like "slow_query_log";

-- 查看慢查询日志的路径
show global variables like "slow_query_log_file";

-- 查看慢查询阈值
show global variables like "long_query_time";

-- 制造一条慢查询
select sleep(1);