-- 开启慢查询额外信息的输出
set global log_slow_extra = on;

-- 制造慢查询
select sleep(1);