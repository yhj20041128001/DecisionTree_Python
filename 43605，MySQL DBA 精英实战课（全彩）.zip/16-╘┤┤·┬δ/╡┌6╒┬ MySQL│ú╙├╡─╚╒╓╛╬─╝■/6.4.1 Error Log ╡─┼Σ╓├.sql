-- 查看Error Log 的路径
show global variables like "log_error";