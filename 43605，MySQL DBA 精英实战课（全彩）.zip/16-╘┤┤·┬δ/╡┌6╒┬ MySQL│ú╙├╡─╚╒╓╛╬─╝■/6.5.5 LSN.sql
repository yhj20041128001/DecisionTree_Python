-- 确认LSN信息
show engine InnoDB status\G