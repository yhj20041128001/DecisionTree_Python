-- 启用Redo Log 归档
set global innodb_redo_log_archive_dirs = "redolog-archiving:/data/mysql/redolog-archiving/";

-- 激活Redo Log 归档
do innodb_redo_log_archive_start("redolog-archiving","redo-20201222");

-- 执行变更操作
create table a3 like a;

-- 停止Redo Log 归档
do innodb_redo_log_archive_stop();