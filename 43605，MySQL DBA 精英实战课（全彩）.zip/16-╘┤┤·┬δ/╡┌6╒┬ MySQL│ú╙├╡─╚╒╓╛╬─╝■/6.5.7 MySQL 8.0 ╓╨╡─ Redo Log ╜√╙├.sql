-- 禁用Redo Log 记录
alter instance disable innodb redo_log;

-- 确认是否禁用
show global status like 'innodb_redo_log_enabled';

-- 运行6.5.2 节创建的批量写入数据的存储过程
call insert_t1();

-- 开启Redo Log
alter instance enable innodb redo_log;

-- 确认是否开启
show global status like 'innodb_redo_log_enabled';

-- 清空 redo_t1
truncate table redo_t1;

-- 重新运行存储过程
call insert_t1();