-- 查看host_cache内存表中的内容
select IP,HOST,HOST_VALIDATED,SUM_CONNECT_ERRORS,FIRST_ERROR_SEEN,LAST_ERROR_SEEN from performance_schema.host_cache\G;

-- 查看调整innodb_buffer_pool_size 参数的进度和状态
show status like "innodb_buffer_pool_resize_status";

-- 调整 innodb_buffer_pool_size
set global innodb_buffer_pool_size = 4*1024*1024*1024;

-- 查看 innodb_buffer_pool_instances 的值
select @@innodb_buffer_pool_instances;

-- 查看 innodb_buffer_pool_size 的值
select @@innodb_buffer_pool_size;

-- 查看 innodb_buffer_pool_size 的值
select @@innodb_buffer_pool_size/1024/1024/1024;

-- 计算
select 2 * 1024 * 1024 * 1024 / (5 * 128 * 1024 * 1024);
select 2.5 * 1024 * 1024 * 1024 / (5 * 128 * 1024 * 1024);

-- 设置 innodb_buffer_pool_size
set global innodb_buffer_pool_size=6*1024;
show warnings;

-- 查看 innodb_buffer_pool_read_requests 的值
show status like 'innodb_buffer_pool_read%';

select 426710057/(426710057+1177)*100;