-- 数据准备
use test
create table `test1` (
`id` int not null auto_increment,
`videoid` int not null default 0,
`memid` int not null default 0,
primary key (`id`),
key `idx_videoid` (`videoid`)
) engine=innodb default charset=utf8mb4;
create table `test2` (
`id` int not null auto_increment,
`videoid` int not null default 0,
`taskid` int not null default 0,
primary key (`id`),
key `idx_videoid` (`videoid`)
) engine=innodb default charset=utf8mb4;

-- 在两张测试表中插入数据
delimiter //
create procedure pro_test()
begin
declare i int;
set i=1;
while(i<=10000)do
insert into test1(videoid,memid) values(i, i);
insert into test2(videoid,taskid) values(i+5, i+5);
set i=i+1;
end while;
end//
delimiter ;
call pro_test();

-- 执行 explain 语句
explain select * from test1 limit 5\G

explain select * from test1 aa join test2 bb on aa.videoid=bb.videoid limit 1\G

explain select * from test1 where videoid in (select videoid from test2 where taskid = 9812 union select videoid from test1 where memid =234)\G

-- Using temporary 举例
explain select * from test1 group by memid\G


-- filesort 举例
explain select * from test1 order by memid\G

-- Using where 举例
explain select * from test1 where memid=1\G

-- Using index 举例
explain select videoid from test1 where videoid=1\G

-- Using join buffer 举例
explain select * from test1 aa join test2 bb on aa.memid=bb.taskid limit 10\G

-- Select tables optimized away 举例
explain select min(videoid) from test2\G