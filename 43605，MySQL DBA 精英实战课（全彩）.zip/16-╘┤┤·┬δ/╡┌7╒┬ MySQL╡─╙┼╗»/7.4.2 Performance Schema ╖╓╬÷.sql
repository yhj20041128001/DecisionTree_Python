-- 查看 performance_schema 是否开启
show variables like 'performance_schema';

-- 配置Performance Schema 库的表启用SQL 剖析，可以看到SQL 的执行过程和耗时
use performance_schema
update performance_schema.setup_instruments set enabled ='YES', timed = 'YES' where name like 'stage%';
update performance_schema.setup_consumers set enabled = 'YES' where name like 'events%';

-- 执行SQL 语句
select * from test.test1 order by memid desc limit 10;

-- 查看执行过程中每个阶段的耗时情况
select a.thread_id,sql_text,c.event_name,(c.timer_end - c.timer_start) / 1000000000 AS 'duration (ms)' from `performance_schema`.events_statements_history_long a join `performance_schema`.threads b on a.thread_id = b.thread_id join `performance_schema`.events_stages_history_long c on c.thread_id = b.thread_id and c.event_id between a.event_id and a.end_event_id where b.processlist_id = connection_id() and a.event_name ='statement/sql/select' order by a.thread_id,c.event_id;


