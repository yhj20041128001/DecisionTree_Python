-- 首先打开追踪器，并设置为JSON 格式
set session optimizer_trace="enabled=on",end_markers_in_json=on;

-- 在表test1 上为memid 也添加索引
alter table test.test1 ADD INDEX idx_memid(memid);

-- 运行SQL 语句
select * from test.test1 where videoid>5000 and memid>8000;

-- 查看追踪的分析结果
select * from INFORMATION_SCHEMA.OPTIMIZER_TRACE;

