-- 创建测试表并写入数据
create table `test_log` (
`id` int not null auto_increment comment 'id',
`member_id` bigint unsigned not null default '0' comment '发布者id',
`content_id` bigint unsigned not null default '0' comment '文章id',
primary key (`id`),
key `content_id` (`content_id`)
) engine=innodb auto_increment=1 default charset=utf8 mb4;
delimiter //
create procedure pro_test_log()
begin
declare i int;
set i=1;
while(i<=30000000)do
insert into test_log(member_id,content_id) values(ceiling(rand()
*500000+500000),ceiling(rand()*500000+1000000));
set i=i+1;
end while;
end//
delimiter ;
call pro_test_log();

-- 分页查询语句
select * from test_log order by id limit 20000000, 10;

-- 利用覆盖查询的方式获取满足条件的偏移量的主键ID
select id from test_log order by id limit 20000000, 1;

-- 根据第一步获取的偏移量的主键ID 进行过滤，然后进行下一步查询
select * from test_log where id>=20000001 order by id limit 10;

-- SQL 语句可以优化为如下形式
select * from test_log where id>=(select id from test_log order by id limit 20000000,1) order by id limit 10;

-- 先利用覆盖索引获取满足条件的主键ID，然后和原表进行join
select a.* from test_log a join ( select id from test_log order by id limit 20000000,10) b on a.id = b.id;


