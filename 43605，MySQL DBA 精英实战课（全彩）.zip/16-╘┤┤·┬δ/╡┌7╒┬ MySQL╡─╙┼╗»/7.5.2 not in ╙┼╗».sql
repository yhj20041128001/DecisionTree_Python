-- 新建一张表并写入数据
create table `pre_log` (
`id` int not null auto_increment comment 'id',
`member_id` bigint unsigned not null default '0' comment '发布者id',
`content_id` bigint unsigned not null default '0' comment '文章id',
primary key (`id`),
key `content_id` (`content_id`)
) engine=innodb auto_increment=1 default charset=utf8 mb4;
delimiter //
create procedure pre_log()
begin
declare i int;
set i=1;
while(i<=1000000)do
insert into pre_log(member_id,content_id) values(ceiling(rand()*
500000+500000),ceiling(rand()*500000+1000000));
set i=i+1;
end while;
end//
delimiter ;
call pre_log();
create table `test_log` (
`id` int not null auto_increment comment 'id',
`member_id` bigint unsigned not null default '0' comment '发布者id',
`content_id` bigint unsigned not null default '0' comment '文章id',
primary key (`id`),
key `content_id` (`content_id`)
) engine=innodb auto_increment=1000001 default charset=utf8 mb4;
delimiter //
create procedure test_log()
begin
declare i int;
set i=1;
while(i<=1000000)do
insert into pre_log(member_id,content_id) values(ceiling(rand()*
500000+500000),ceiling(rand()*500000+1000000));
set i=i+1;
end while;
end//
delimiter ;
call test_log();

-- 要执行的SQL 语句如下
select * from test_log where content_id not in (select content_id from pre_log);

-- 执行计划如下
explain select * from test_log where content_id not in(select content_id from pre_log)\G

-- 改写的SQL 语句的执行计划
explain select * from test_log a left join pre_log b on a.content_id=b.content_id where b.content_id is null\G
