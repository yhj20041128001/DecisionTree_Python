-- 建表语句
create table `test_order` (
`id` int not null auto_increment comment 'id',
`a` int unsigned not null default '0',
`b` int unsigned not null default '0',
`c` varchar(64) not null default '',
`d` int default null,
primary key (`id`),
key `idx_a_b_c` (`a`,`b`,`c`),
key `idx_d` (`d`)
) engine=innodb default charset=utf8mb4;

-- 插入数据
delimiter //
create procedure pro_test_order()
begin
declare i int;
set i=1;
while(i<=10000)do
insert into test_order(a,b,c,d) values(i, i,substring(MD5(RAND()),
1,20),i);
set i=i+1;
end while;
end//
delimiter ;
call pro_test_order();

-- 以下查询是可以用到索引idx_a_b_c 的，MySQL 不用再利用sort_buffer 排序
select * from test_order where a = 100 order by b;
select * from test_order where a = 100 order by a;
select * from test_order where a = 100 and b = 200 order by b;
select * from test_order where a = 100 and b = 200 order by c;
select * from test_order where a = 100 order by b desc, c desc ;
select * from test_order where a = 100 order by b asc, c asc;
select * from test_order where a > 100 order by a;
select * from test_order where a = 100 and b > 200 order by b;
select * from test_order where a = 100 and b = 200 order by c desc ,id desc ;

-- 使用索引排序时不遵守最左前缀的原则，中间跳过字段:
explain select * from test_order where a = 100 order by c\G

explain select * from test_order order by a, c\G

-- SQL 语句在排序时并没有用到索引
explain select * from test_order where a=100 order by b asc,c desc\G

-- SQL 语句进行了全表扫描
explain select * from test_order where a>100 order by b\G

-- 索引idx_a_b_c(a,b,c)变为idx_a_b_c(a,b,c(32))
explain select * from test_order where a = 100 and b = 200 order by c\G

-- SQL 语句进行了全表扫描
explain select * from test_order order by b,a\G

-- 排序的字段在不同的索引中，无法使用索引排序
explain select * from test_order order by a,d\G