-- 下面是group by 字段能使用索引的情况
select * from test_order where a = 100 group by b;
select * from test_order where a = 100 group by a;
select * from test_order where a = 100 and b = 200 group by b;
select * from test_order where a = 100 and b = 200 group by c;
select * from test_order where a > 100 group by a;
select * from test_order where a = 100 and b > 200 group by b;