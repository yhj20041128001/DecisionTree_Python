-- 建表并写入测试数据
create table `test_log` (
`id` int not null auto_increment comment 'id',
`member_id` bigint unsigned not null default '0' comment '发布者id',
`content_id` bigint unsigned not null default '0' comment '文章id',
primary key (`id`),
key `content_id` (`content_id`)
) engine=innodb auto_increment=1000001 default charset=utf8 mb4;
delimiter //
create procedure test_log()
begin
declare i int;
set i=1;
while(i<=1000000)do
insert into pre_log(member_id,content_id) values(ceiling(rand()*
500000+500000),ceiling(rand()*500000+1000000));
set i=i+1;
end while;
end//
delimiter ;
call test_log();

-- SQL 语句的where 条件选择的数据过多导致全表扫描的示例
explain select * from test_log where content_id > 100000 and content_id < 10000000\G

-- 使用force index方式后变为如下形式
explain select * from test_log force index(content_id) where content_id > 100000 and content_id < 10000000\G