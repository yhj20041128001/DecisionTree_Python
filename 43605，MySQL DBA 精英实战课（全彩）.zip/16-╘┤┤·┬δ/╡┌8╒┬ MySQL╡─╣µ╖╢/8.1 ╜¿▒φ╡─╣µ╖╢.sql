-- 使用保留字报错的例子
create table aa(id int,column varchar(10));

-- 使用保留字正确的方式
create table aa(id int,`column` varchar(10));

-- 查询数据
select * from aa;

-- 写入数据
insert into aa select 1,'a';

-- 查询数据报错的例子
select * from aa where column='a';

-- 查询数据正确的例子
select * from aa where `column`='a';

-- 规范的表示例如下：
create table student_info (
id int (11) unsigned not null auto_increment comment '主键',
stu_name varchar (10) not null default '' comment '姓名',
stu_class varchar (10) not null default '' comment '班级',
stu_num int (11) not null default '0' comment '学号',
stu_score smallint unsigned not null default '0' comment '总分',
tuition decimal (5, 2) not null default '0' comment '学费',
phone_number varchar (20) not null default '0' comment '电话号码',
create_time datetime not null default current_timestamp comment
'记录创建时间',
update_time datetime not null default current_timestamp on update
current_timestamp comment '记录更新时间',
status tinyint not null default '1' comment '1 代表记录有效，0 代表记
录无效',
primary key (id),
unique key uniq_stu_num (stu_num),
key idx_stu_score (stu_score),
key idx_update_time_tuition (update_time, tuition)
) engine = InnoDB charset = utf8mb4 comment '学生信息表';