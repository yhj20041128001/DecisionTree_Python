-- 创建测试表并写入数据
use test; /* 使用test 数据库 */
drop table if exists t1; /* 如果表t1 存在则删除表t1 */
create table `t1` ( /* 创建表t1 */
`id` int not null auto_increment,
`a` varchar(20) default null,
`b` int default null,
`c` datetime not null default current_timestamp,
primary key (`id`),
key `idx_a` (`a`) using btree,
key `idx_b` (`b`) using btree
) engine=innodb default charset=utf8mb4;
drop procedure if exists insert_t1; /* 如果存在存储过程insert_t1，则删除 */
delimiter ;;
create procedure insert_t1() /* 创建存储过程insert_t1 */
begin
declare i int; /* 声明变量i */
set i=1; /* 设置i 的初始值为1 */
while(i<=10000)do /* 对满足i<=10000 的值进行while 循环 */
insert into t1(a,b) values(i,i); /* 写入表t1 中的a 字段和b 字段的值
都为i 当前的值 */
set i=i+1; /* 将i 加1 */
end while;
end;;
delimiter ;
call insert_t1();


-- 对a 字段的值不加单引号的情况如下：
explain select a,b,c from t1 where a=100\G

-- 对a 字段的值加单引号的情况如下
explain select a,b,c from t1 where a='100'\G

-- 分开的两条alter 语句如下
alter table t1 add column d int DEFAULT NULL;
alter table t1 add column e int DEFAULT NULL;