-- 在Master 节点上创建用户，并授权replication slave 权限
create user rep@'172.16.%' identified by '1234abcd';
grant replication slave on *.* to 'rep'@'172.16.%' ;

-- 在Master 节点上查看开始同步的位点信息
show master status\G


-- 在Slave 节点初始化Slave 节点连接Master 节点的同步信息
change master to
master_host='172.16.163.114',
master_user='rep',
master_password='1234abcd',
master_log_file='mysql-bin.000002',
master_log_pos=156;

-- 开启同步复制
start slave;

-- 查看同步状态
show slave status\G;

