-- 在Slave 节点上初始化Slave 节点连接Master 节点的同步信息
change master to
master_host='172.16.163.114',
master_user='rep',
master_password='abcd1234',
master_port=3306,
master_auto_position = 1;

-- Slave 节点开启同步复制
start slave

-- 查看同步状态
show slave status\G;

