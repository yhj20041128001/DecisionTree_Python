-- 查看 gtid_executed 的几条命令
show master status\G;
show global variables like '%gtid_executed';
select * from mysql.gtid_executed;

-- 查看 gtid_purged
show variables like '%gtid_purged%';

