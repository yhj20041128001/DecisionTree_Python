-- 查看复制状态
show slave status\G;


-- 跳过复制报错
stop slave;
set @@session.gtid_next= '4feb66d2-e77e-11ea-96fd-00163e08e185:2';

begin;commit;

set session gtid_next = AUTOMATIC;

start slave;

show slave status\G;