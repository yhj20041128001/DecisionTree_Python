-- 并行复制 Master 节点的配置
gtid_mode=ON
enforce-gtid-consistency=1

-- 并行复制Slave 节点的配置
gtid_mode=ON
enforce-gtid-consistency=1
slave-parallel-type=LOGICAL_CLOCK
slave-parallel-workers=16
master_info_repository=TABLE
relay_log_info_repository=TABLE
relay_log_recovery=ON
slave_preserve_commit_order = ON


-- 如果要开启基于WRITESET 的并行复制模式，那么Master 节点需要新增如下配置
loose-binlog_transaction_dependency_tracking = WRITESET
loose-transaction_write_set_extraction = XXHASH64
binlog_transaction_dependency_history_size = 25000 # 默认